<?php

namespace TheTwelve\Foursquare;

class ListsGateway extends EndpointGateway
{

}
