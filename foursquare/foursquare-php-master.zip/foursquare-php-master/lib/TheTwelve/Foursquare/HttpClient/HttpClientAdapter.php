<?php

namespace TheTwelve\Foursquare\HttpClient;

use TheTwelve\Foursquare\HttpClient;

abstract class HttpClientAdapter implements HttpClient
{



}
