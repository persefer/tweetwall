<?php

namespace TheTwelve\Foursquare;

class CheckinsGateway extends EndpointGateway
{

}
