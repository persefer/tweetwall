<?php

namespace TheTwelve\Foursquare;

class TipsGateway extends EndpointGateway
{

}
