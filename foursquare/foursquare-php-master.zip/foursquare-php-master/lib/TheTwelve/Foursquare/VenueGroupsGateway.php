<?php

namespace TheTwelve\Foursquare;

class VenueGroupsGateway extends EndpointGateway
{

}
